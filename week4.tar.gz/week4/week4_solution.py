import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from collections import defaultdict
import gymnasium as gym

np.random.seed(42)

env = gym.make('Blackjack-v1', sab=True)

def simple_policy(state):
    player_sum, dealer_card, usable_ace = state
    return 0 if player_sum >= 20 else 1

def generate_episode(env, policy):
    episode = []
    state, _ = env.reset()
    done = False
    
    while not done:
        action = policy(state)
        next_state, reward, terminated, truncated, _ = env.step(action)
        done = terminated or truncated
        episode.append((state, action, reward))
        state = next_state
    
    return episode

def mc_prediction(env, policy, num_episodes=10000):
    returns_sum = defaultdict(float)
    returns_count = defaultdict(int)
    V = defaultdict(float)
    
    for i in range(num_episodes):
        episode = generate_episode(env, policy)
        
        G = 0
        visited = set()
        
        for t in range(len(episode) - 1, -1, -1):
            state, action, reward = episode[t]
            G = reward
            
            if state not in visited:
                visited.add(state)
                returns_sum[state] += G
                returns_count[state] += 1
                V[state] = returns_sum[state] / returns_count[state]
    
    return V

print("Running MC Prediction with 10,000 episodes...")
V = mc_prediction(env, simple_policy, num_episodes=10000)

print("\nState Values:")
print(f"V(Player=21, Dealer=10, No Ace): {V.get((21, 10, False), 0):.4f}")
print(f"V(Player=21, Dealer=10, Usable Ace): {V.get((21, 10, True), 0):.4f}")
print(f"V(Player=15, Dealer=10, No Ace): {V.get((15, 10, False), 0):.4f}")
print(f"V(Player=20, Dealer=5, No Ace): {V.get((20, 5, False), 0):.4f}")

def epsilon_greedy_policy(Q, epsilon, n_actions=2):
    def policy(state):
        if np.random.random() < epsilon:
            return np.random.randint(n_actions)
        else:
            q_values = [Q[state][a] for a in range(n_actions)]
            return np.argmax(q_values)
    return policy

def mc_control(env, num_episodes=500000, alpha=0.01, epsilon=0.1):
    Q = defaultdict(lambda: np.zeros(2))
    rewards_history = []
    current_epsilon = epsilon
    
    for i in range(num_episodes):
        policy = epsilon_greedy_policy(Q, current_epsilon)
        episode = generate_episode(env, policy)
        
        episode_reward = episode[-1][2]
        rewards_history.append(episode_reward)
        
        G = 0
        visited = set()
        
        for t in range(len(episode) - 1, -1, -1):
            state, action, reward = episode[t]
            G = reward
            
            state_action = (state, action)
            if state_action not in visited:
                visited.add(state_action)
                Q[state][action] += alpha * (G - Q[state][action])
        
        current_epsilon *= 0.99999
        current_epsilon = max(current_epsilon, 0.01)
        
        if (i + 1) % 100000 == 0:
            print(f"Episode {i+1}/{num_episodes} completed")
    
    optimal_policy = lambda state: np.argmax(Q[state])
    
    return Q, optimal_policy, rewards_history

print("\nRunning MC Control with 500,000 episodes...")
print("This will take a few minutes...\n")

Q, optimal_policy, rewards_history = mc_control(env, num_episodes=500000)

print(f"\nTraining completed!")
print(f"Final average reward: {np.mean(rewards_history[-1000:]):.4f}")

window = 1000
rolling_avg = np.convolve(rewards_history, np.ones(window)/window, mode='valid')

plt.figure(figsize=(14, 6))
plt.plot(rolling_avg, linewidth=2)
plt.axhline(y=0, color='r', linestyle='--', alpha=0.5)
plt.xlabel('Episode', fontsize=12)
plt.ylabel('Average Reward', fontsize=12)
plt.title('Learning Curve: Monte Carlo Control on Blackjack', fontsize=14)
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig('learning_curve.png', dpi=300, bbox_inches='tight')
print("\nSaved learning_curve.png")

def plot_strategy(Q, usable_ace=False):
    player_sums = range(12, 22)
    dealer_cards = range(1, 11)
    
    policy_grid = np.zeros((len(player_sums), len(dealer_cards)))
    
    for i, player_sum in enumerate(player_sums):
        for j, dealer_card in enumerate(dealer_cards):
            state = (player_sum, dealer_card, usable_ace)
            if state in Q:
                policy_grid[i, j] = np.argmax(Q[state])
            else:
                policy_grid[i, j] = 1
    
    plt.figure(figsize=(12, 8))
    
    cmap = sns.color_palette(["#e74c3c", "#2ecc71"], as_cmap=True)
    
    ax = sns.heatmap(
        policy_grid,
        cmap=cmap,
        cbar_kws={'label': 'Action', 'ticks': [0.25, 0.75]},
        xticklabels=dealer_cards,
        yticklabels=player_sums,
        linewidths=0.5,
        linecolor='gray',
        square=True,
        vmin=0,
        vmax=1
    )
    
    colorbar = ax.collections[0].colorbar
    colorbar.set_ticklabels(['STICK', 'HIT'])
    
    plt.xlabel('Dealer Showing', fontsize=12)
    plt.ylabel('Player Sum', fontsize=12)
    
    ace_text = "With Usable Ace" if usable_ace else "Without Usable Ace"
    plt.title(f'Optimal Blackjack Strategy\n{ace_text}', fontsize=14)
    
    plt.tight_layout()
    filename = f'strategy_ace_{usable_ace}.png'
    plt.savefig(filename, dpi=300, bbox_inches='tight')
    print(f"Saved {filename}")

plot_strategy(Q, usable_ace=False)
plot_strategy(Q, usable_ace=True)

print("\n" + "="*60)
print("PART III - THEORETICAL QUESTIONS")
print("="*60)

print("\nQuestion A: The Infinite Deck Assumption")
print("-"*60)

print("\n1. Non-Stationarity:")
print("   In a finite deck, the probability of drawing cards changes")
print("   based on what's already been dealt. Two states with the same")
print("   (PlayerSum, DealerCard) can have different probabilities")
print("   depending on the cards removed from the deck.")
print("   This violates the Markov property because the next state")
print("   depends on history, not just current state.")

print("\n2. State Space Design for Card Counting:")
print("   S = (PlayerSum, DealerCard, UsableAce, RunningCount)")
print("   ")
print("   Where RunningCount tracks:")
print("   - Low cards (2-6): +1")
print("   - Neutral (7-9): 0")
print("   - High cards (10, A): -1")
print("   ")
print("   This captures deck composition information needed for")
print("   optimal play in finite deck scenarios.")

print("\n3. The Trade-off:")
print("   Original state space: ~200 states")
print("   With running count (-50 to +50): ~20,000 states")
print("   ")
print("   More states means:")
print("   - Need many more episodes to visit each state")
print("   - Slower convergence (might need 10M+ episodes)")
print("   - Higher memory requirements")
print("   - May need function approximation instead of tables")

print("\n\nQuestion B: First-Visit vs Every-Visit")
print("-"*60)

print("\nScenario: A → B → A → Terminate")
print("Rewards: r(A→B) = +1, r(B→A) = -1, r(A→Term) = +10")

print("\n1. First-Visit Monte Carlo:")
print("   Only counts the first occurrence of state A")
print("   G(A) = r0 + r1 + r2 = (+1) + (-1) + (+10) = 10")

print("\n2. Every-Visit Monte Carlo:")
print("   Counts all occurrences of state A")
print("   Visit 1: G0 = (+1) + (-1) + (+10) = 10")
print("   Visit 2: G2 = (+10) = 10")
print("   Average: (10 + 10) / 2 = 10")

print("\n   In this case, both methods give the same result: 10")
print("   Both converge to the true value with enough samples.")

print("\n" + "="*60)
print("All tasks completed!")
print("="*60)
