import numpy as np
import matplotlib.pyplot as plt

np.random.seed(42)

N_GAMBLERS = 10000
N_ROUNDS = 1000
START_BANKROLL = 100.0

outcomes = np.random.choice([-1, 1], size=(N_GAMBLERS, N_ROUNDS))

cumulative_changes = np.cumsum(outcomes, axis=1)
bankroll = np.zeros((N_GAMBLERS, N_ROUNDS + 1))
bankroll[:, 0] = START_BANKROLL
bankroll[:, 1:] = START_BANKROLL + cumulative_changes

ruin_mask = bankroll <= 0
ruin_mask = np.maximum.accumulate(ruin_mask, axis=1)
bankroll[ruin_mask] = 0

fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 10))

for i in range(100):
    ax1.plot(bankroll[i], alpha=0.3, color='gray', linewidth=0.5)

mean_path = np.mean(bankroll, axis=0)
max_winner_idx = np.argmax(bankroll[:, -1])
max_loser_idx = np.argmin(bankroll[:, -1])

ax1.plot(mean_path, 'r--', linewidth=2.5, label='Mean Path')
ax1.plot(bankroll[max_winner_idx], 'g-', linewidth=2, label='Max Winner')
ax1.plot(bankroll[max_loser_idx], 'b-', linewidth=2, label='Max Loser')

ax1.set_title('Gambler Trajectories (First 100 + Extremes)', fontsize=14, fontweight='bold')
ax1.set_xlabel('Rounds', fontsize=12)
ax1.set_ylabel('Bankroll ($)', fontsize=12)
ax1.legend(loc='best', fontsize=10)
ax1.grid(True, alpha=0.3)

final_wealth = bankroll[:, -1]
ax2.hist(final_wealth, bins=50, alpha=0.7, color='steelblue', edgecolor='black')

mean_final = np.mean(final_wealth)
median_final = np.median(final_wealth)

ax2.axvline(mean_final, color='red', linestyle='--', linewidth=2.5, label=f'Mean: ${mean_final:.2f}')
ax2.axvline(median_final, color='orange', linestyle='--', linewidth=2.5, label=f'Median: ${median_final:.2f}')

ax2.set_title('Final Wealth Distribution (10,000 Gamblers)', fontsize=14, fontweight='bold')
ax2.set_xlabel('Final Bankroll ($)', fontsize=12)
ax2.set_ylabel('Number of Gamblers', fontsize=12)
ax2.legend(loc='best', fontsize=10)
ax2.grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig('gamblers_ruin_simulation.png', dpi=300, bbox_inches='tight')