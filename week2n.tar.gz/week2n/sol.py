#!/usr/bin/env python3
"""
Week 2.5: Monte Carlo Quant Finance ONLY
IIT Bombay CSE - Black-Scholes + Greeks
S&P500 ATM Call Option (Dec 2025)
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import norm

np.random.seed(42)
plt.rcParams['figure.figsize'] = (12, 8)

class BlackScholesMC:
    def __init__(self):
        pass
    
    @staticmethod
    def bs_price(S0, K, T, r, sigma, option_type='call'):
        '''Exact Black-Scholes formula'''
        d1 = (np.log(S0/K) + (r + 0.5*sigma**2)*T) / (sigma*np.sqrt(T))
        d2 = d1 - sigma*np.sqrt(T)
        
        if option_type == 'call':
            return S0*norm.cdf(d1) - K*np.exp(-r*T)*norm.cdf(d2)
        else:
            return K*np.exp(-r*T)*norm.cdf(-d2) - S0*norm.cdf(-d1)
    
    def monte_carlo_price(self, S0, K, T, r, sigma, N_paths=100_000):
        '''Monte Carlo GBM pricing'''
        Z = np.random.standard_normal(N_paths)
        ST = S0 * np.exp((r - 0.5*sigma**2)*T + sigma*np.sqrt(T)*Z)
        
        call_payoff = np.maximum(ST - K, 0)
        put_payoff = np.maximum(K - ST, 0)
        
        call_price = np.exp(-r*T) * np.mean(call_payoff)
        put_price = np.exp(-r*T) * np.mean(put_payoff)
        
        return call_price, put_price, ST
    
    def greeks_monte(self, S0, K, T, r, sigma, N_paths=500_000):
        '''MC Greeks (Delta via finite difference)'''
        call_p0, _, _ = self.monte_carlo_price(S0, K, T, r, sigma, N_paths)
        eps = 0.01
        call_p1, _, _ = self.monte_carlo_price(S0+eps, K, T, r, sigma, N_paths)
        delta_mc = (call_p1 - call_p0) / eps
        
        exact_call = self.bs_price(S0, K, T, r, sigma)
        exact_delta = norm.cdf((np.log(S0/K) + (r + 0.5*sigma**2)*T) / (sigma*np.sqrt(T)))
        
        return {
            'MC_Call': call_p0, 'Exact_Call': exact_call,
            'MC_Delta': delta_mc, 'Exact_Delta': exact_delta
        }

# =============================================================================
# MAIN EXECUTION
# =============================================================================
if __name__ == "__main__":
    print("=== WEEK 2.5: QUANT FINANCE MONTE CARLO ===\n")
    
    # S&P500 parameters (Dec 2025)
    S0, K, T, r, sigma = 5800, 6000, 0.25, 0.04, 0.15  # 3mo ATM call
    
    bs = BlackScholesMC()
    results = bs.greeks_monte(S0, K, T, r, sigma)
    
    print(f"S&P500 ATM CALL OPTION:")
    print(f"S0=${S0:,.0f}  K=${K:,.0f}  T={T}yr  r={r}  σ={sigma}")
    print(f"Call Price:  MC=${results['MC_Call']:.2f}  |  BS=${results['Exact_Call']:.2f}")
    print(f"Delta:       MC={results['MC_Delta']:.3f}  |  BS={results['Exact_Delta']:.3f}\n")
    
    # Convergence analysis
    N_paths = [1_000, 10_000, 100_000, 500_000, 1_000_000]
    mc_prices, mc_stds = [], []
    
    for n in N_paths:
        price, _, ST = bs.monte_carlo_price(S0, K, T, r, sigma, n)
        mc_prices.append(price)
        mc_stds.append(np.std(np.maximum(ST - K, 0)) * np.exp(-r*T) / np.sqrt(n))
    
    exact_price = results['Exact_Call']
    errors = 100 * np.abs(np.array(mc_prices) - exact_price) / exact_price
    
    print("Convergence Table:")
    print("N_paths    Price    Error%    MC_Std%")
    for i, n in enumerate(N_paths):
        print(f"{n:8,}  {mc_prices[i]:6.2f}  {errors[i]:6.2f}   {100*mc_stds[i]/exact_price:6.2f}")
    
    # Plot results
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))
    
    ax1.semilogx(N_paths, mc_prices, 'bo-', linewidth=3, markersize=8, label='MC Price')
    ax1.axhline(exact_price, color='r', ls='--', linewidth=3, label='Exact BS')
    ax1.set_title('S&P500 Call Convergence'); ax1.set_ylabel('Price ($)'); ax1.legend()
    ax1.grid(True, alpha=0.3)
    
    ax2.semilogx(N_paths, errors, 'ro-', linewidth=3, markersize=8, label='Error %')
    ax2.semilogx(N_paths, 100*np.array(mc_stds)/exact_price, 'g.-', label='MC Std %')
    ax2.set_title('Error Analysis'); ax2.set_ylabel('Error/Std %'); ax2.legend()
    ax2.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig('quant_convergence.png', dpi=300, bbox_inches='tight')
    plt.show()
    
    print("\n✅ QUANT FINANCE COMPLETE: quant_convergence.png saved")
