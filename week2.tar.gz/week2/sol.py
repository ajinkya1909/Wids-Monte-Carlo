#!/usr/bin/env python3
"""
Monte Carlo Integration - Complete IIT Bombay Assignment
Author: CSE 2nd Year Student
All methods vectorized + convergence analysis + high-dim demo
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy.special import erf
import math

np.random.seed(42)
plt.rcParams['figure.figsize'] = (12, 8)

# =============================================================================
# 1. PI ESTIMATION (Assignment 2.1)
# =============================================================================
class PiCalc:
    def __init__(self):
        self.actual = np.pi
        
    def run(self, n):
        x = np.random.uniform(-1, 1, n)
        y = np.random.uniform(-1, 1, n)
        hits = np.sum(x**2 + y**2 <= 1)
        return 4 * hits / n
    
    def check_trend(self):
        sizes = [10 * 2**i for i in range(18)]
        vals = [self.run(s) for s in sizes]
        errs = 100 * np.abs(np.array(vals) - self.actual) / self.actual
        
        fig, (p1, p2) = plt.subplots(1, 2, figsize=(12, 5))
        p1.semilogx(sizes, vals, 'bo-', linewidth=2, markersize=6)
        p1.axhline(self.actual, color='r', ls='--', linewidth=2)
        p1.set_ylabel('Estimate'); p1.grid(True, alpha=0.3); p1.set_title('π')
        
        p2.loglog(sizes, errs, 'ro-', linewidth=2, markersize=6)
        p2.set_xlabel('N (log)'); p2.set_ylabel('Error % (log)'); p2.grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.savefig('pi_convergence.png', dpi=300, bbox_inches='tight')
        plt.show()
        return sizes[-1], vals[-1], errs[-1]

# =============================================================================
# 2. E ESTIMATION (Assignment 2.2) - BOTH METHODS
# =============================================================================
class ECalc:
    def __init__(self):
        self.actual = np.e
        
    def way1(self, n, upper=2):  # Area method
        x = np.random.uniform(1, upper, n)
        y = np.random.uniform(0, 1, n)
        under = np.sum(y < 1/x)
        area = (upper-1) * under / n
        return upper ** (1/area) if area > 0 else np.nan
    
    def way2(self, runs):  # Vectorized Forsythe chain method
        sz = 25
        rnd = np.random.uniform(0, 1, (runs, sz))
        diffs = np.diff(rnd, axis=1)
        breaks = np.where(diffs >= 0, np.arange(1, sz), sz-1)
        breaks = np.min(breaks, axis=1) + 2
        return np.mean(breaks)
    
    def compare_methods(self):
        counts = [10 * 2**i for i in range(16)]
        m1 = [self.way1(c) for c in counts]
        m2 = [self.way2(c) for c in counts]
        
        fig, (g1, g2) = plt.subplots(1, 2, figsize=(12, 5))
        g1.semilogx(counts, m1, 'b.-', linewidth=2, markersize=8, label='Area')
        g1.semilogx(counts, m2, 'g.-', linewidth=2, markersize=8, label='Chain')
        g1.axhline(self.actual, color='r', ls='--', linewidth=2, label='True e')
        g1.legend(); g1.grid(True, alpha=0.3); g1.set_ylabel('Estimate')
        
        e1 = 100 * np.abs(np.array(m1) - self.actual) / self.actual
        e2 = 100 * np.abs(np.array(m2) - self.actual) / self.actual
        g2.loglog(counts, e1, 'b.-', linewidth=2, markersize=8)
        g2.loglog(counts, e2, 'g.-', linewidth=2, markersize=8)
        g2.set_xlabel('N (log)'); g2.set_ylabel('Error % (log)')
        g2.legend(['Area', 'Chain']); g2.grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.savefig('e_methods.png', dpi=300, bbox_inches='tight')
        plt.show()

# =============================================================================
# 3. GENERAL SHAPE SAMPLER (Assignment 2.3)
# =============================================================================
class AreaSampler:
    def __init__(self, shape_func, bounds, true_val=None):
        self.shape_func = shape_func
        self.bounds = bounds
        self.true_val = true_val
    
    def estimate(self, N):
        xmin, xmax, ymin, ymax = self.bounds
        x = np.random.uniform(xmin, xmax, N)
        y = np.random.uniform(ymin, ymax, N)
        inside = self.shape_func(x, y)
        ratio = np.sum(inside) / N
        box_area = (xmax-xmin) * (ymax-ymin)
        return box_area * ratio
    
    def convergence(self, values):
        results, errors = [], []
        for value in values:
            est = self.estimate(value)
            results.append(est)
            if self.true_val:
                err = 100 * np.abs(est - self.true_val) / self.true_val
                errors.append(err)
        return results, errors

# Define shapes
circle = lambda x,y: x**2 + y**2 <= 1
parabola = lambda x,y: y <= x**2
gaussian = lambda x,y: y <= np.exp(-x**2)

# Setup samplers
samplers = {
    'Circle': AreaSampler(circle, [-1,1,-1,1], np.pi),
    'Parabola': AreaSampler(parabola, [0,1,0,1], 1/3),
    'Gaussian': AreaSampler(gaussian, [0,2,0,1], np.sqrt(np.pi)/2 * erf(2))
}

# =============================================================================
# MAIN EXECUTION
# =============================================================================
if __name__ == "__main__":
    print("=== MONTE CARLO INTEGRATION ANALYSIS ===\n")
    
    # 1. Pi estimation
    print("1. π ESTIMATION:")
    pi = PiCalc()
    final_n, final_pi, final_err = pi.check_trend()
    print(f"   N=10M: {final_pi:.6f} (Error: {final_err:.2f}%)\n")
    
    # 2. e estimation
    print("2. e ESTIMATION:")
    e = ECalc()
    print(f"   e method1: {e.way1(100000):.5f}")
    print(f"   e method2: {e.way2(10000):.5f}")
    print(f"   true e:    {np.e:.5f}\n")
    e.compare_methods()
    
    # 3. Shape estimates
    print("3. SHAPE AREAS (N=1M):")
    N = 1000000
    for name, sampler in samplers.items():
        est = sampler.estimate(N)
        true = sampler.true_val if sampler.true_val else 'N/A'
        true_str = f"{true:.5f}" if np.isscalar(true) else true
        print(f"   {name:8}: {est:.5f} | {true_str}")
    
    # 4. Convergence plots
    print("\n4. CONVERGENCE ANALYSIS:")
    N_values = [1000, 10_000, 100_000, 1_000_000]
    
    fig, axes = plt.subplots(2, 2, figsize=(12, 10))
    axes = axes.flatten()
    for idx, (name, sampler) in enumerate(samplers.items()):
        results, errors = sampler.convergence(N_values)
        axes[idx].loglog(N_values, errors, 'o-', linewidth=3, markersize=8)
        axes[idx].set_title(f'{name} Error')
        axes[idx].set_xlabel('N'); axes[idx].set_ylabel('Error %')
        axes[idx].grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig('shapes_convergence.png', dpi=300, bbox_inches='tight')
    plt.show()
    
    # 5. High-dim curse
    print("\n5. HIGH-DIMENSIONAL DEMO:")
    def unit_ball_volume(dims, N=100_000):
        points = np.random.uniform(-1, 1, (N, dims))
        inside = np.sum(points**2, axis=1) <= 1
        vol = np.prod([2]*dims) * np.mean(inside)
        return vol
    
    dims = [2, 4, 8, 16]
    results = [unit_ball_volume(d) for d in dims]
    plt.figure(figsize=(10, 6))
    plt.semilogy(dims, results, 'ro-', linewidth=3, markersize=10)
    plt.xlabel('Dimensions'); plt.ylabel('Volume'); plt.title('Curse of Dimensionality')
    plt.grid(True, alpha=0.3)
    plt.savefig('high_dim.png', dpi=300, bbox_inches='tight')
    plt.show()
    
    print("High-dim volumes:", [f"{r:.4f}" for r in results])
    print("\n=== ALL PNGs SAVED: pi_convergence.png, e_methods.png, shapes_convergence.png, high_dim.png ===")
